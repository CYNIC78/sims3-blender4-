"""Преобразование CLIP → локальные трансформы костей (без bpy).

Как это работает
----------------
Игра хранит для каждого джойнта два независимых набора значений:
позицию и ориентацию (кватернион, порядок xyzw) — в системе координат
родителя. Оригинальный плагин кладёт их в позу так:

    pose[joint] = pose[parent] @ Translation(P) @ Rotation(Q)

Blender же хранит локальную «базу» кости (matrix_basis), и

    pose[bone] = pose[parent] @ (rest[parent]^-1 @ rest[bone]) @ basis[bone]

Подставляя одно в другое, родительская поза сокращается, и получается
чистая локальная формула:

    basis[bone] = (rest[parent]^-1 @ rest[bone])^-1 @ Translation(P) @ Rotation(Q)

Для корневой кости (без родителя) вместо offset берётся rest[bone].
Именно это и считает этот модуль — поэтому не нужно ни выставлять позы
по одной, ни обновлять depsgraph.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from .clipfile import ClipAnim, ClipTrack
from .fnv import fnv1_32
from . import mat, naming
from .mat import Mat4, Quat, Vec3

IDENTITY = mat.identity()

FRAME_INTERP_LINEAR = "linear"
FRAME_INTERP_STEP = "step"


@dataclass
class JointRest:
    """Кость скелета в rest-позе."""

    name: str
    parent: int  # индекс родителя или -1
    matrix_local: Mat4  # bone.matrix_local (в системе арматуры)
    # альтернативные имена (после переименования в .L/.R и т.п.)
    aliases: Tuple[str, ...] = ()


@dataclass
class Skeleton:
    joints: List[JointRest]

    def hash_map(self) -> Dict[int, int]:
        """FNV32-хеш имени (и всех его вариантов) → индекс кости."""
        out: Dict[int, int] = {}
        for index, joint in enumerate(self.joints):
            for name in (joint.name,) + tuple(joint.aliases) + naming.name_variants(joint.name):
                if not name:
                    continue
                key = fnv1_32(name)
                # кость, у которой имя совпало «как есть», важнее алиаса
                if key not in out or name == joint.name:
                    out[key] = index
        return out

    def offsets(self) -> List[Mat4]:
        """rest[parent]^-1 @ rest[bone] (для корня — просто rest[bone])."""
        out: List[Mat4] = []
        for joint in self.joints:
            rest = joint.matrix_local
            if joint.parent < 0:
                out.append(rest)
            else:
                parent_rest = self.joints[joint.parent].matrix_local
                out.append(mat.mul(mat.inverse_rigid(parent_rest), rest))
        return out


@dataclass
class BakeOptions:
    dense: bool = True  # ключ на каждом кадре (рекомендуется для FBX)
    interpolate: str = FRAME_INTERP_LINEAR  # линейно между «родными» кадрами
    frame_start: int = 0
    frame_end: Optional[int] = None
    # что подставлять костям, для которых в клипе нет данных позиции
    missing_position: str = "relative"  # 'relative' | 'absolute' (как в оригинале)
    # вращение безродительской кости: 'identity' — как в оригинальном плагине
    root_rotation: str = "identity"
    # конвенция данных: absolute — значения parent-relative как есть (как в оригинале),
    # delta — значения являются дельтой от rest-позы
    position_mode: str = "absolute"  # 'absolute' | 'delta'
    rotation_mode: str = "absolute"  # 'absolute' | 'delta'
    # проверить 4 комбинации и выбрать ту, где поза ближе к rest-позе
    auto_convention: bool = True
    # домножить позиции (масштаб юнитов)
    scale: float = 1.0


@dataclass
class BoneCurves:
    index: int
    name: str
    positions: List[Tuple[int, Vec3]] = field(default_factory=list)
    rotations: List[Tuple[int, Quat]] = field(default_factory=list)


@dataclass
class BakeResult:
    frame_start: int
    frame_end: int
    bones: List[BoneCurves]
    unmatched_hashes: List[int]
    morph_tracks: List[ClipTrack]
    fps: float
    warnings: List[str] = field(default_factory=list)

    @property
    def matched_bones(self) -> int:
        return len(self.bones)


# --------------------------------------------------------------------------
def _sample(
    keys: Sequence[Tuple[int, Sequence[float]]],
    frame: int,
    mode: str,
    is_rotation: bool,
):
    if not keys:
        return None
    if frame <= keys[0][0]:
        return tuple(keys[0][1])
    if frame >= keys[-1][0]:
        return tuple(keys[-1][1])

    # бинарный поиск интервала
    lo, hi = 0, len(keys) - 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if keys[mid][0] <= frame:
            lo = mid
        else:
            hi = mid
    f0, v0 = keys[lo]
    f1, v1 = keys[hi]
    if mode == FRAME_INTERP_STEP or f1 == f0:
        return tuple(v0)
    t = (frame - f0) / float(f1 - f0)
    if is_rotation:
        return mat.quat_slerp(tuple(v0), tuple(v1), t)
    return tuple(a + (b - a) * t for a, b in zip(v0, v1))


def bake_clip(anim: ClipAnim, skeleton: Skeleton, options: Optional[BakeOptions] = None) -> BakeResult:
    options = options or BakeOptions()
    hashes = skeleton.hash_map()
    offsets = skeleton.offsets()

    track_of: Dict[int, ClipTrack] = {}
    unmatched: List[int] = []
    morphs: List[ClipTrack] = []
    for key, track in anim.tracks.items():
        if track.is_morph_only:
            morphs.append(track)
            continue
        idx = hashes.get(key)
        if idx is None:
            unmatched.append(key)
        else:
            track_of[idx] = track

    frame_start = max(0, options.frame_start)
    frame_end = options.frame_end if options.frame_end is not None else anim.frame_end
    frame_end = max(frame_start, frame_end)

    if options.dense:
        frames: List[int] = list(range(frame_start, frame_end + 1))
    else:
        used = {frame_start}
        for track in track_of.values():
            used.update(f for f, _v in track.positions)
            used.update(f for f, _v in track.orientations)
        frames = sorted(used)

    curves: Dict[int, BoneCurves] = {}
    for idx, track in track_of.items():
        curves[idx] = BoneCurves(index=idx, name=skeleton.joints[idx].name)

    # считаем только кости, у которых есть данные: локальная база кости
    # не зависит от родителей, поэтому весь скелет перебирать не нужно
    tracked = sorted(track_of.items())

    for frame in frames:
        for idx, track in tracked:
            joint = skeleton.joints[idx]
            offsets_idx = offsets[idx]
            pos = _sample(track.positions, frame, options.interpolate, False)
            rot = _sample(track.orientations, frame, options.interpolate, True)

            if pos is not None:
                if options.position_mode == "delta":
                    base = mat.to_translation(offsets_idx)
                    pos = (pos[0] + base[0], pos[1] + base[1], pos[2] + base[2])
                if options.scale != 1.0:
                    pos = (pos[0] * options.scale, pos[1] * options.scale, pos[2] * options.scale)
                t_mat = mat.translation(pos)
            elif options.missing_position == "absolute":
                t_mat = mat.translation(mat.to_translation(joint.matrix_local))
            else:  # 'relative' — кость остаётся в своей rest-позиции относительно родителя
                t_mat = mat.translation(mat.to_translation(offsets_idx))

            if rot is not None:
                if joint.parent < 0 and options.root_rotation == "identity":
                    r_mat = IDENTITY  # поведение оригинального плагина
                else:
                    if options.rotation_mode == "delta":
                        rot = mat.quat_mul(mat.to_quat(offsets_idx), rot)
                    r_mat = mat.from_quat(rot)
            else:
                r_mat = mat.rest_rotation(offsets_idx)

            target = mat.mul(t_mat, r_mat)
            basis = mat.mul(mat.inverse_rigid(offsets_idx), target)

            entry = curves[idx]
            if track.positions:
                entry.positions.append((frame, mat.to_translation(basis)))
            if track.orientations:
                entry.rotations.append((frame, mat.to_quat(basis)))

    warnings = list(anim.warnings)
    if unmatched:
        warnings.append(
            "%d трек(ов) не сопоставлено с костями скелета (нужны имена джойнтов игры)"
            % len(unmatched)
        )
    if morphs:
        warnings.append("%d морф-трек(ов) пропущено (в FBX не переносятся)" % len(morphs))

    return BakeResult(
        frame_start=frame_start,
        frame_end=frame_end,
        bones=sorted(curves.values(), key=lambda b: b.index),
        unmatched_hashes=sorted(unmatched),
        morph_tracks=morphs,
        fps=anim.fps,
        warnings=warnings,
    )


def guess_joint_names(skeleton: Skeleton, hashes: Sequence[int]) -> Dict[int, str]:
    """Пытается найти имя кости по «похожему» хешу — для диагностики.

    Полезно, когда клип снят с другой модели: показываем, на что похож
    неопознанный ключ, сравнивая с хешами костей скелета без учёта регистра
    и с обрезанными служебными префиксами.
    """
    variants = {}
    for joint in skeleton.joints:
        name = joint.name
        variants[fnv1_32(name)] = name
        if name.startswith("b__") and name.endswith("__"):
            short = name[3:-2]
            variants.setdefault(fnv1_32(short), name)
    return {h: variants[h] for h in hashes if h in variants}
