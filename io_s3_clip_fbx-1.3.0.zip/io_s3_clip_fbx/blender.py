"""Blender-слой: скелет → экшены → FBX."""

from __future__ import annotations

import os
import re

import bpy

from .s3clip import bake as s3bake
from .s3clip import naming
from .s3clip.clipfile import ClipAnim
from .s3clip.mat import Mat4

S3_ADDON_ID = "io_s3_clip_fbx"

_INTERP_VALUES = {
    item.identifier: item.value
    for item in bpy.types.Keyframe.bl_rna.properties["interpolation"].enum_items
}


# --------------------------------------------------------------------------
# Скелет
# --------------------------------------------------------------------------
def skeleton_from_armature(arm_obj: bpy.types.Object) -> s3bake.Skeleton:
    bones = arm_obj.data.bones
    index = {b.name: i for i, b in enumerate(bones)}
    joints = []
    for bone in bones:
        flat: Mat4 = tuple(v for row in bone.matrix_local for v in row)
        aliases = []
        stored = bone.get(naming.S3_NAME_PROP)
        if isinstance(stored, str) and stored and stored != bone.name:
            aliases.append(stored)
        joints.append(
            s3bake.JointRest(
                name=bone.name,
                parent=index[bone.parent.name] if bone.parent else -1,
                matrix_local=flat,
                aliases=tuple(aliases),
            )
        )
    return s3bake.Skeleton(joints)


def armature_bone_names(arm_obj: bpy.types.Object):
    return [b.name for b in arm_obj.data.bones]


def find_armature(context, explicit=None) -> bpy.types.Object | None:
    if explicit is not None and explicit.type == "ARMATURE":
        return explicit
    obj = context.active_object
    if obj is not None:
        if obj.type == "ARMATURE":
            return obj
        for mod in obj.modifiers:
            if mod.type == "ARMATURE" and mod.object:
                return mod.object
    candidates = [o for o in context.scene.objects if o.type == "ARMATURE"]
    if len(candidates) == 1:
        return candidates[0]
    return candidates[0] if candidates else None


# --------------------------------------------------------------------------
# Экшены
# --------------------------------------------------------------------------
def _new_fcurve(action, data_path: str, index: int, group_name: str):
    try:  # Blender <= 4.3 и legacy-слой в 4.4+
        return action.fcurves.new(data_path, index=index, action_group=group_name)
    except Exception:
        pass
    # современный API со слотами (Blender 4.4+)
    if not action.slots:
        action.slots.new(id_type="OBJECT", name="Armature")
    slot = action.slots[0]
    if not action.layers:
        action.layers.new("Layer")
    layer = action.layers[0]
    if not layer.strips:
        layer.strips.new(type="KEYFRAME")
    strip = layer.strips[0]
    bag = strip.channelbag(slot, ensure=True)
    return bag.fcurves.new(data_path, index=index)


def _fill_fcurve(fcurve, frames, values, interpolation: str, group=None):
    count = len(frames)
    if not count:
        return
    fcurve.keyframe_points.add(count)
    flat = []
    for frame, value in zip(frames, values):
        flat.append(float(frame))
        flat.append(float(value))
    fcurve.keyframe_points.foreach_set("co", flat)
    code = _INTERP_VALUES.get(interpolation.upper(), 1)
    fcurve.keyframe_points.foreach_set("interpolation", [code] * count)
    try:
        fcurve.update()
    except Exception:
        pass


def _assign_action(arm_obj, action):
    ad = arm_obj.animation_data or arm_obj.animation_data_create()
    ad.action = action
    if hasattr(ad, "action_slot"):
        try:
            if action.slots and ad.action_slot is None:
                ad.action_slot = action.slots[0]
        except Exception:
            pass
    return ad


def build_action(
    arm_obj: bpy.types.Object,
    anim: ClipAnim,
    options: s3bake.BakeOptions | None = None,
    action_name: str | None = None,
    interpolation: str = "LINEAR",
    variants=None,
):
    """Создаёт экшен на арматуре и возвращает (action, BakeResult)."""
    options = options or s3bake.BakeOptions()
    skeleton = skeleton_from_armature(arm_obj)

    detected = None
    if options.auto_convention:
        from .s3clip import diagnose as s3diag

        order = anim.field_order
        pos_mode, rot_mode = options.position_mode, options.rotation_mode
        scores = {}
        best_score = 0.0

        if variants and len(variants) > 1:
            order, pos_mode, rot_mode, order_scores = s3diag.detect_field_order(
                variants, skeleton, options
            )
            anim = variants[order]
            scores = order_scores
            best_score = order_scores.get(order, 0.0)
            print(
                "[S3 Clip→FBX] порядок полей в кривых: %s (сдвиг от rest: %s)"
                % (order, {k: round(v, 2) for k, v in order_scores.items()})
            )
        else:
            pos_mode, rot_mode, conv_scores = s3diag.detect_convention(anim, skeleton, options)
            scores = conv_scores
            best_score = conv_scores.get((pos_mode, rot_mode), 0.0)
            if (pos_mode, rot_mode) != ("absolute", "absolute"):
                print(
                    "[S3 Clip→FBX] авто-конвенция: позиции=%s, повороты=%s (сдвиг от rest %.2f м)"
                    % (pos_mode, rot_mode, best_score)
                )

        detected = (pos_mode, rot_mode, scores)
        if best_score > 1.0:
            print(
                "[S3 Clip→FBX] ВНИМАНИЕ: даже лучший вариант уводит кости на %.2f м от rest. "
                "Похоже на проблему в самом файле — запустите «Диагностика клипа»." % best_score
            )

        options = s3bake.BakeOptions(
            dense=options.dense,
            interpolate=options.interpolate,
            frame_start=options.frame_start,
            frame_end=options.frame_end,
            missing_position=options.missing_position,
            root_rotation=options.root_rotation,
            position_mode=pos_mode,
            rotation_mode=rot_mode,
            scale=options.scale,
            auto_convention=False,
        )

    result = s3bake.bake_clip(anim, skeleton, options)

    name = action_name or (anim.name or os.path.basename(anim.path) or "s3_clip")
    action = bpy.data.actions.new(name)
    action.use_fake_user = False

    for bone_curves in result.bones:
        bone_name = bone_curves.name
        data_path = 'pose.bones["%s"].' % bone_name
        if bone_curves.positions:
            frames = [f for f, _v in bone_curves.positions]
            for axis in range(3):
                values = [v[axis] for _f, v in bone_curves.positions]
                fc = _new_fcurve(action, data_path + "location", axis, bone_name)
                _fill_fcurve(fc, frames, values, interpolation)
        if bone_curves.rotations:
            frames = [f for f, _v in bone_curves.rotations]
            # CLIP хранит xyzw, Blender — wxyz
            for axis, src in enumerate((3, 0, 1, 2)):
                values = [v[src] for _f, v in bone_curves.rotations]
                fc = _new_fcurve(action, data_path + "rotation_quaternion", axis, bone_name)
                _fill_fcurve(fc, frames, values, interpolation)

    # метаданные клипа
    action["s3_clip_name"] = anim.name
    action["s3_source_file"] = anim.source_file
    action["s3_actor_name"] = anim.actor_name
    action["s3_frame_start"] = result.frame_start
    action["s3_frame_end"] = result.frame_end
    action["s3_position_mode"] = options.position_mode
    action["s3_rotation_mode"] = options.rotation_mode
    action["s3_field_order"] = anim.field_order
    if detected:
        action["s3_convention_scores"] = "%s" % {
            (k if isinstance(k, str) else "%s/%s" % k): round(v, 3)
            for k, v in detected[2].items()
        }

    _assign_action(arm_obj, action)
    return action, result


def set_quaternion_mode(arm_obj: bpy.types.Object):
    changed = 0
    for pbone in arm_obj.pose.bones:
        if pbone.rotation_mode != "QUATERNION":
            pbone.rotation_mode = "QUATERNION"
            changed += 1
    return changed


def clear_animation(arm_obj: bpy.types.Object):
    arm_obj.animation_data_clear()
    if arm_obj.data.animation_data:
        arm_obj.data.animation_data_clear()


def reset_pose(arm_obj: bpy.types.Object):
    for pbone in arm_obj.pose.bones:
        pbone.location = (0.0, 0.0, 0.0)
        pbone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
        pbone.rotation_euler = (0.0, 0.0, 0.0)
        pbone.scale = (1.0, 1.0, 1.0)


# --------------------------------------------------------------------------
# FBX
# --------------------------------------------------------------------------
def _supported_kwargs(op, kwargs: dict) -> dict:
    try:
        props = set(op.get_rna_type().properties.keys())
    except Exception:
        return kwargs
    return {k: v for k, v in kwargs.items() if k in props}


def ensure_fbx_addon() -> bool:
    if hasattr(bpy.ops.export_scene, "fbx"):
        return True
    try:
        bpy.ops.preferences.addon_enable(module="io_scene_fbx")
    except Exception:
        return False
    return hasattr(bpy.ops.export_scene, "fbx")


def _select_only(context, objects):
    for obj in context.view_layer.objects:
        obj.select_set(False)
    for obj in objects:
        obj.select_set(True)
    if objects:
        context.view_layer.objects.active = objects[0]


def export_fbx(
    context,
    filepath: str,
    arm_obj: bpy.types.Object,
    *,
    include_meshes: bool = False,
    scale: float = 1.0,
    add_leaf_bones: bool = False,
    axis_forward: str = "-Z",
    axis_up: str = "Y",
    nla_strips: bool = False,
    bake_all_actions: bool = False,
    all_bones: bool = True,
    deform_bones_only: bool = False,
):
    """Экспортирует арматуру (и, при желании, её меши) в FBX."""
    ensure_fbx_addon()
    previous_selection = [obj for obj in context.view_layer.objects if obj.select_get()]
    previous_active = context.view_layer.objects.active
    objects = [arm_obj]
    if include_meshes:
        for child in arm_obj.children_recursive:
            if child.type == "MESH":
                objects.append(child)
    _select_only(context, objects)

    if not nla_strips and not bake_all_actions:
        ad = arm_obj.animation_data
        if ad is not None and ad.action is not None and hasattr(ad, "action_slot"):
            try:
                if ad.action.slots and ad.action_slot is None:
                    ad.action_slot = ad.action.slots[0]
            except Exception:
                pass

    object_types = {"ARMATURE"}
    if include_meshes:
        object_types.add("MESH")

    kwargs = dict(
        filepath=filepath,
        use_selection=True,
        use_active_collection=False,
        object_types=object_types,
        apply_scale_options="FBX_SCALE_NONE",
        global_scale=scale,
        apply_unit_scale=True,
        axis_forward=axis_forward,
        axis_up=axis_up,
        use_space_transform=True,
        bake_space_transform=False,
        add_leaf_bones=add_leaf_bones,
        primary_bone_axis="Y",
        secondary_bone_axis="X",
        use_armature_deform_only=deform_bones_only,
        armature_nodetype="NULL",
        bake_anim=True,
        bake_anim_use_all_bones=all_bones,
        bake_anim_use_nla_strips=nla_strips,
        bake_anim_use_all_actions=bake_all_actions,
        bake_anim_force_startend_keying=True,
        bake_anim_step=1.0,
        bake_anim_simplify_factor=0.0,
        use_mesh_modifiers=False,
        mesh_smooth_type="FACE",
        path_mode="AUTO",
        embed_textures=False,
        use_custom_props=False,
        bake_space_transform_=False,
    )
    kwargs.pop("bake_space_transform", None)
    kwargs = _supported_kwargs(bpy.ops.export_scene.fbx, kwargs)

    os.makedirs(os.path.dirname(os.path.abspath(filepath)) or ".", exist_ok=True)
    try:
        result = bpy.ops.export_scene.fbx(**kwargs)
    finally:
        # возвращаем выделение пользователя
        try:
            for obj in context.view_layer.objects:
                obj.select_set(False)
            for obj in previous_selection:
                try:
                    obj.select_set(True)
                except Exception:
                    pass
            context.view_layer.objects.active = previous_active
        except Exception:
            pass
    if "FINISHED" not in result:
        raise RuntimeError("экспорт FBX не удался: %s" % (result,))
    return filepath


# --------------------------------------------------------------------------
# Имена файлов
# --------------------------------------------------------------------------
_BAD_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def sanitize_filename(name: str, fallback: str = "clip") -> str:
    name = (name or "").strip()
    name = _BAD_CHARS.sub("_", name)
    name = name.strip(" .")
    return name or fallback


def output_name(template: str, anim: ClipAnim, path: str, index: int) -> str:
    stem = os.path.splitext(os.path.basename(path))[0]
    clip = anim.name or stem
    try:
        rendered = template.format(name=clip, stem=stem, index=index, actor=anim.actor_name or "")
    except Exception:
        rendered = clip
    return sanitize_filename(rendered) + ".fbx"


# --------------------------------------------------------------------------
# Переименование костей Sims 3 ⇄ .L/.R (симметрия весов)
# --------------------------------------------------------------------------
import re as _re

_BONE_PATH = _re.compile(r'^pose\.bones\["([^"]+)"\]\.')


def iter_action_fcurves(action):
    """F-curves экшена для legacy-API и для слотового API Blender 4.4+."""
    try:
        curves = list(action.fcurves)
    except Exception:
        curves = []
    if curves:
        yield from curves
        return
    for layer in getattr(action, "layers", []):
        for strip in layer.strips:
            for slot in getattr(action, "slots", []):
                try:
                    bag = strip.channelbag(slot)
                except Exception:
                    bag = None
                if bag is not None:
                    yield from bag.fcurves


def _rename_vertex_groups(arm_obj, mapping):
    """Переименовывает вершинные группы на мешах, привязанных к ригу."""
    targets = set()
    for obj in bpy.data.objects:
        if obj.type != "MESH":
            continue
        for mod in obj.modifiers:
            if mod.type == "ARMATURE" and mod.object == arm_obj:
                targets.add(obj)
                break
        else:
            if obj.parent == arm_obj:
                targets.add(obj)
    touched = 0
    for obj in targets:
        for group in obj.vertex_groups:
            new_name = mapping.get(group.name)
            if not new_name:
                continue
            if new_name in obj.vertex_groups and obj.vertex_groups[new_name] != group:
                continue  # не плодим дубликаты
            group.name = new_name
            touched += 1
    return touched


def _rename_fcurve_paths(mapping):
    touched = 0
    for action in bpy.data.actions:
        for fcurve in iter_action_fcurves(action):
            match = _BONE_PATH.match(fcurve.data_path)
            if not match:
                continue
            bone_name = match.group(1)
            new_name = mapping.get(bone_name)
            if not new_name:
                continue
            fcurve.data_path = fcurve.data_path.replace(
                'pose.bones["%s"]' % bone_name, 'pose.bones["%s"]' % new_name, 1
            )
            touched += 1
    return touched


def rename_bones_side_mode(arm_obj, to_mirror: bool):
    """Переименовывает кости в `.L/.R` (или обратно) с сохранением исходных имён.

    Возвращает dict с количеством переименованных костей, вершинных групп и f-curve.
    """
    from .s3clip import naming

    bones = arm_obj.data.bones
    existing = {bone.name for bone in bones}
    mapping_plan = {}

    for bone in bones:
        if to_mirror:
            if naming.is_mirror_name(bone.name):
                continue
            new_name = naming.to_mirror(bone.name)
            if not new_name or new_name in existing:
                continue
            mapping_plan[bone.name] = new_name
        else:
            stored = bone.get(naming.S3_NAME_PROP)
            if not naming.is_mirror_name(bone.name) and not stored:
                continue
            new_name = naming.from_mirror(bone.name, stored if isinstance(stored, str) else None)
            if not new_name or new_name in existing:
                continue
            mapping_plan[bone.name] = new_name

    if not mapping_plan:
        return {"bones": 0, "vertex_groups": 0, "fcurves": 0, "mapping": {}}

    # сохраняем исходные имена (для точного возврата)
    for old_name, new_name in mapping_plan.items():
        bone = bones[old_name]
        if to_mirror:
            if naming.S3_NAME_PROP not in bone.keys():
                bone[naming.S3_NAME_PROP] = old_name
        else:
            try:
                del bone[naming.S3_NAME_PROP]
            except Exception:
                pass

    for old_name, new_name in mapping_plan.items():
        bones[old_name].name = new_name

    groups = _rename_vertex_groups(arm_obj, mapping_plan)
    curves = _rename_fcurve_paths(mapping_plan)
    return {
        "bones": len(mapping_plan),
        "vertex_groups": groups,
        "fcurves": curves,
        "mapping": mapping_plan,
    }


def has_mirror_names(arm_obj) -> bool:
    """Есть ли на риге кости в режиме .L/.R."""
    from .s3clip import naming

    for bone in arm_obj.data.bones:
        if naming.is_mirror_name(bone.name) or naming.S3_NAME_PROP in bone.keys():
            return True
    return False
